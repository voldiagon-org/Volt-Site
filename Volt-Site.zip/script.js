git add  all
git commit -m "Initial commit"
git push origin main